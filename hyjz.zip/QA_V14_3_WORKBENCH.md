Hongyuan V14.3 Workbench QA

Scope
- Reworked Hero Carousel floating workbench UI based on the requested compact tab navigation.
- Removed the vertical element-card list from the visible workbench flow.
- Added a single horizontal element-tab row with horizontal scroll support and a dedicated horizontal scrollbar/range control.
- Added a dedicated vertical scroll container for the settings editor so lower controls remain reachable.
- Kept the existing slide form fields associated with slideForm after moving the floating panel to document.body.

Static checks
- admin/index.php PHP syntax: PASS
- admin/save_slide.php PHP syntax: PASS
- All PHP files: 46 files PASS
- All inline scripts in admin/index.php: PASS (Node --check)
- slides INSERT columns/placeholders: 53 / 53 PASS
- ZIP root layout: website files are at ZIP root; no extra project directory layer.

Workbench structural checks
- elementIndex remains visible as compact top tabs.
- No generated vertical v14-layerbar is used.
- elementEditor is wrapped in .v14-editor-scroll with overflow-y:auto.
- Horizontal tab range synchronizes with elementIndex scrollLeft.
- Wheel over the tab strip converts vertical wheel movement into horizontal tab scrolling.
- Window remains fixed-position and retains drag/resize handlers.
- 8 resize handles remain present: N, S, E, W, NE, NW, SE, SW.
- Existing backend modules and slide CRUD code were not removed.

Known test boundary
- The execution environment does not provide the site's production authentication/session or SQLite PDO driver, so live production browser login/database testing cannot be claimed here.
