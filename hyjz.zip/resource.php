<?php
require_once __DIR__.'/inc/db.php';
$slug=trim($_GET['slug']??'');
$q=db()->prepare('SELECT r.*,p.name product_name,p.slug product_slug FROM resources r LEFT JOIN products p ON p.id=r.product_id WHERE r.slug=? AND r.published=1 LIMIT 1');
$q->execute([$slug]);$r=$q->fetch(PDO::FETCH_ASSOC);if($r&&trim($r['title'])==='')$r=null;
if(!$r){http_response_code(404);require __DIR__.'/404.php';exit;}
$page_title=($r['seo_title']??'')?:($r['title'].' | '.setting('company_name'));
$page_desc=($r['seo_description']??'')?:($r['description']?:'Technical resource from '.setting('company_name').'.');$og_image=$r['image']?:setting('default_og_image','assets/factory.jpg');
$canonical=site_url('resource.php?slug='.urlencode($r['slug']));
require __DIR__.'/inc/header.php';
?>
<section class="page-hero"><div class="wrap"><div class="breadcrumb"><a href="<?=e(site_url('resources.php'))?>">Resources</a> / <?=e($r['title'])?></div><div class="eyebrow"><?=e($r['type'])?></div><h1><?=e($r['title'])?></h1><p><?=e(plain_text_clean($r['description']))?></p></div></section>
<section class="section"><div class="wrap"><div class="detail"><div><?php if($r['image']):?><img class="application-hero-img" src="<?=e(site_url($r['image']))?>" alt="<?=e($r['title'])?>"><?php elseif(!empty($r['file']) && in_array(strtolower(pathinfo($r['file'],PATHINFO_EXTENSION)),['jpg','jpeg','png','webp'],true)):?><img class="application-hero-img" src="<?=e(site_url($r['file']))?>" alt="<?=e($r['title'])?>" style="width:100%;height:auto;object-fit:contain;max-height:620px"><?php else:?><div style="background:#11161b;min-height:280px;display:grid;place-items:center;color:#fff;font-size:44px;font-weight:800"><?=e(strtoupper(substr($r['type'],0,3)))?></div><?php endif;?></div><div><span class="eyebrow dark">TECHNICAL RESOURCE</span><h2><?=e($r['title'])?></h2><div class="resource-desc"><?=rich_text_clean($r['description'])?></div><?php if($r['product_name']):?><p>Related product: <a class="text-link" href="<?=e(site_url('product.php?slug='.urlencode($r['product_slug'])))?>"><?=e($r['product_name'])?></a></p><?php endif;?><?php if($r['file']&&is_file(__DIR__.'/'.$r['file'])):?><a class="btn-dark" target="_blank" rel="noopener" href="<?=e(site_url('download_resource.php?id='.(int)$r['id']))?>" data-track="resource-download">Open / Download →</a><?php endif;?></div></div></div></section>
<?php require __DIR__.'/inc/footer.php'; ?>
