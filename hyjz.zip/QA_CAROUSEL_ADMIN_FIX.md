# Carousel Admin Fix

## Fixed
- Removed duplicate `image_file` input in the Hero Carousel editor. The previous duplicate field could cause PHP to receive the empty second file field, making a selected banner appear to do nothing.
- Added visible client-side upload status and a clear 20 MB browser-side guard.
- Added server-side upload error feedback instead of silently failing.
- Added `.user.ini` with 32M upload / 40M POST limits for compatible shared hosting.
- Made the right-side carousel property panel sticky with its own viewport scroll on desktop, while returning to normal flow on tablet/mobile.
- Removed artificial HTML min/max restrictions from line-height fields; they now accept safe CSS line-height values such as `1.2`, `1.5`, `24px`, `1.5em`, `120%`, or `normal`.
- Backend line-height validation now accepts the same safe CSS value forms.

## QA
- PHP lint: all PHP files pass.
- Existing static/runtime QA suite: 180 PASS / 0 FAIL / 0 WARN.
- SQLite integrity: checked.
