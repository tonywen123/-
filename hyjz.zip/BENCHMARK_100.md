# Hongyuan Final — 100-site B2B website benchmark corpus

This is the benchmark sample used for the final architecture. It is a curated corpus of company-owned B2B/industrial/graphics/printing-material websites, grouped by the buyer journey they are strong at. It is not a claim that every site was audited feature-by-feature at the same depth.

## A. Graphics / self-adhesive / film / signage
1. ORAFOL
2. Avery Dennison Graphics
3. 3M Commercial Graphics
4. HEXIS
5. Arlon Graphics
6. General Formulations
7. Mactac
8. Drytac
9. Neschen
10. Metamark
11. Spandex
12. FDC Graphic Films
13. R-Tape
14. Sihl
15. ImageBond
16. Ultraflex
17. Verseidag
18. Heytex
19. Serge Ferrari
20. Cooley
21. ASLAN
22. POLI-TAPE
23. KPMF
24. APA America
25. Lintec Europe

## B. Adhesives / tapes / labels / coated materials
26. tesa
27. Nitto
28. Lohmann
29. Scapa
30. LINTEC
31. FLEXcon
32. UPM Raflatac
33. Avery Dennison Label & Packaging Materials
34. Fedrigoni
35. Mondi
36. Sappi
37. Koehler Paper
38. Yupo
39. Neenah
40. Lecta
41. Domtar
42. Antalis
43. Essentra
44. Brady
45. CCL Industries
46. HERMA
47. Label Supply
48. MACtac Tapes
49. 3M Tapes
50. Henkel Adhesive Technologies

## C. Printing / wide-format / finishing equipment
51. HP Large Format
52. Canon Large Format
53. Epson Professional Printing
54. Roland DG
55. Mimaki
56. Mutoh
57. Agfa
58. Durst
59. EFI
60. swissQprint
61. Fujifilm Graphic Systems
62. Graphtec
63. Summa
64. Zünd
65. Kongsberg PCS
66. Esko
67. Kala
68. Royal Sovereign
69. GBC
70. Vivid Laminating Technologies

## D. Industrial materials / chemicals / engineered products
71. BASF
72. Covestro
73. Dow
74. DuPont
75. Henkel
76. 3M Industrial
77. Avery Dennison Industrial
78. Saint-Gobain
79. Evonik
80. Arkema
81. Wacker
82. Eastman
83. SABIC
84. Celanese
85. Huntsman

## E. Industrial / manufacturing / technical B2B UX references
86. Bosch Rexroth
87. Parker Hannifin
88. Emerson
89. Rockwell Automation
90. Siemens Industry
91. Schneider Electric
92. SKF
93. Festo
94. SMC
95. TE Connectivity
96. Phoenix Contact
97. Honeywell Industrial Automation
98. ABB
99. Rockwell Automation Partner Network
100. Fastenal

## Feature patterns extracted into Hongyuan
- Mega navigation organized by **product family + application**.
- Product finder/search with SKU/model/specification discovery.
- Application-first paths that recommend products.
- Product detail pages that behave like technical sales sheets rather than simple catalog cards.
- Structured specifications that can feed comparison and filtering.
- Side-by-side product comparison and shortlisting.
- Multi-product RFQ lists rather than one-product contact forms.
- Sample request as a separate conversion path.
- Technical resource/document center with downloadable files.
- Case/application gallery and factory proof.
- Search autocomplete and search analytics.
- CRM-like inquiry pipeline: status, priority, assignment, follow-up and notes.
- UTM/source attribution for marketing campaigns.
- SEO controls, canonical URLs, sitemap, robots, Open Graph and structured data.
- Secure admin sessions, password hashing, CSRF protection and protected customer attachments.
- Responsive mobile navigation and mobile RFQ actions.
- Hero carousel that is visually clean by default, while keeping an optional CMS-controlled overlay.

## Core sources used for feature verification
- ORAFOL: product/application structure and download centre.
- Avery Dennison Graphics: product/application discovery, resource centre, training, case studies and tools.
- Drytac: product catalog, resource hub, guides, ICC profiles, manuals and support.
- General Formulations: product taxonomy and technical data / ICC profile access.
- Mactac: application-focused resource libraries and technical product selector patterns.
- Flexcon: enhanced search, mega navigation, market/product/capability paths and product comparison.
- tesa: product finder, technical attributes, comparison and contact escalation.
- Covestro: product finder, sample request and quote workflow.
- BASF: product finder + industry segmentation.
- HP: equipment + media + workflow + certified media paths.
