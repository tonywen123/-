Hongyuan V14.4.6 SAFE CODE PACKAGE

This package is intended as a code-only overwrite package.

It deliberately does NOT contain:
- data.sqlite
- uploads/
- existing product images
- existing media files

Therefore uploading/overwriting this package will not replace the site's current product database or uploaded media.

Main changes:
1. Hero Carousel now has a separate Hero Editing Modes group:
   - PC Editor
   - Mobile Editor
   - Open Workbench
2. Mobile editing is independent from PC editing.
3. Mobile has its own JSON settings, image, text, positions, typography, overlay, button, URL and visibility settings.
4. Mobile editor has its own floating workbench with minimize/maximize/close, undo/redo, live preview and independent canvas dragging.
5. Public frontend reads the mobile settings at max-width 700px and falls back to the PC banner when no mobile image is present.
6. Existing PC editor remains intact.

Deployment:
- Upload/overwrite the code files from this ZIP.
- Do not delete data.sqlite or uploads/ on the server.
- The database migration adds the mobile_settings column automatically when the site first loads.
