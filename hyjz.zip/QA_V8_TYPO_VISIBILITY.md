# V8 Typography / Visibility QA

- Eyebrow and Title have explicit Show / Hide controls in the carousel editor.
- Visibility is persisted per slide through `show_eyebrow` and `show_title` columns, added safely by `admin/save_slide.php` when needed.
- Public homepage renders banner text independently of the optional overlay layer.
- Typography size ranges widened to avoid unnecessary editor limits.
- Letter spacing and line-height remain CSS-value fields with server-side safe validation.
- Live style updates are scheduled through `requestAnimationFrame` to avoid excessive synchronous redraws while typing.
- Malformed duplicate `>` characters in line-height inputs removed.
- PHP syntax: PASS.
- Existing QA suite: 180 PASS / 0 FAIL / 0 WARN.
- DB workflow QA: 15 PASS.
- Typography QA: 8 PASS / 0 FAIL.
