<?php
require_once __DIR__.'/../inc/auth.php'; require_admin();
$pdo=db();
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location:index.php?tab=slides&mode=mobile');exit;}
csrf_check();
$id=(int)($_POST['id']??0);
if(!$id){header('Location:index.php?tab=slides&mode=mobile&error='.rawurlencode('Please select an existing slide.'));exit;}
$q=$pdo->prepare('SELECT id,mobile_image,mobile_settings FROM slides WHERE id=?');$q->execute([$id]);$row=$q->fetch(PDO::FETCH_ASSOC);
if(!$row){header('Location:index.php?tab=slides&mode=mobile&error='.rawurlencode('Slide not found.'));exit;}
$mobileImage=(string)($row['mobile_image']??'');
if(!empty($_POST['remove_mobile_image']))$mobileImage='';
if(isset($_FILES['mobile_image_file']) && (int)($_FILES['mobile_image_file']['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){
 $f=$_FILES['mobile_image_file'];$err=(int)($f['error']??UPLOAD_ERR_OK);
 if($err!==UPLOAD_ERR_OK){header('Location:index.php?tab=slides&mode=mobile&edit_slide='.$id.'&error='.rawurlencode('Mobile banner upload failed with PHP error '.$err.'.'));exit;}
 if((int)$f['size']>15*1024*1024){header('Location:index.php?tab=slides&mode=mobile&edit_slide='.$id.'&error='.rawurlencode('Mobile banner is too large. Maximum supported size is 15 MB.'));exit;}
 $mime=detect_upload_mime($f['tmp_name'],$f['name']);$allowed=['image/jpeg','image/png','image/webp','image/gif'];
 if(!in_array($mime,$allowed,true)){header('Location:index.php?tab=slides&mode=mobile&edit_slide='.$id.'&error='.rawurlencode('Unsupported mobile banner format. Use JPG, PNG, WEBP or GIF.'));exit;}
 $info=@getimagesize($f['tmp_name']);if(!$info||empty($info[0])||empty($info[1])||$info[0]>12000||$info[1]>12000){header('Location:index.php?tab=slides&mode=mobile&edit_slide='.$id.'&error='.rawurlencode('Mobile banner dimensions are invalid or exceed 12000 px.'));exit;}
 $up=upload_file('mobile_image_file','uploads/slides',$allowed);if(!$up){header('Location:index.php?tab=slides&mode=mobile&edit_slide='.$id.'&error='.rawurlencode('The mobile banner could not be stored. Check uploads/slides permission.'));exit;}
 $mobileImage=$up['path'];$pdo->prepare('INSERT INTO media(filename,path,mime,size) VALUES(?,?,?,?)')->execute([$up['filename'],$up['path'],$up['mime'],$up['size']]);
}
$raw=trim((string)($_POST['mobile_settings']??''));$decoded=[];
if($raw!==''){ $tmp=json_decode($raw,true); if(is_array($tmp))$decoded=$tmp; }
$allowedKeys=['width','height','image_fit','image_position','overlay_enabled','overlay_color','overlay_opacity','show_eyebrow','show_title','eyebrow','title','description','button_text','button_url','eyebrow_x','eyebrow_y','title_x','title_y','text_x','text_y','button_x','button_y','text_width','text_align','eyebrow_size','eyebrow_color','eyebrow_font','eyebrow_weight','eyebrow_letter_spacing','eyebrow_line_height','eyebrow_align','title_size','title_color','title_font','title_weight','title_letter_spacing','title_line_height','title_align','desc_size','desc_color','desc_font','desc_weight','desc_letter_spacing','desc_line_height','button_font_size','button_text_color','button_bg_color','button_border_color','button_width','button_height','button_radius','button_font','button_weight','button_letter_spacing','button_line_height','link_target','alt_text'];
$clean=[];foreach($allowedKeys as $k){if(array_key_exists($k,$decoded)){ $v=$decoded[$k]; if(is_string($v))$v=trim($v); if(is_scalar($v)||$v===null)$clean[$k]=$v; }}
$json=json_encode($clean,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
$pdo->prepare('UPDATE slides SET mobile_image=?, mobile_settings=? WHERE id=?')->execute([$mobileImage,$json,$id]);
header('Location:index.php?tab=slides&mode=mobile&edit_slide='.$id.'&saved=1');exit;
