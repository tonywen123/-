<?php
require_once __DIR__.'/../inc/auth.php';
require_admin();
if(empty($_GET['csrf_token'])||empty($_SESSION['csrf'])||!hash_equals($_SESSION['csrf'],(string)$_GET['csrf_token'])){http_response_code(419);exit('操作页面已过期，请刷新后重试。');}
$pdo=db();
$id=(int)($_GET['id']??0);
$q=$pdo->prepare('SELECT * FROM product_media WHERE id=?');
$q->execute([$id]);
$row=$q->fetch(PDO::FETCH_ASSOC);
if(!$row){header('Location:index.php?tab=products');exit;}
if(isset($_GET['move'])){
  $dir=$_GET['move']==='up'?-1:1;
  $q=$pdo->prepare('SELECT id,sort_order FROM product_media WHERE product_id=? ORDER BY sort_order,id');
  $q->execute([(int)$row['product_id']]);
  $arr=$q->fetchAll(PDO::FETCH_ASSOC);$pos=0;
  foreach($arr as $i=>$x){if((int)$x['id']===$id){$pos=$i;break;}}
  $np=$pos+$dir;
  if(isset($arr[$np])){
    $other=$arr[$np];
    $pdo->prepare('UPDATE product_media SET sort_order=? WHERE id=?')->execute([$other['sort_order'],$id]);
    $pdo->prepare('UPDATE product_media SET sort_order=? WHERE id=?')->execute([$row['sort_order'],$other['id']]);
  }
}
if(isset($_GET['delete'])){
  $q=$pdo->prepare('SELECT media_id,product_id FROM product_media WHERE id=?');
  $q->execute([$id]);$link=$q->fetch(PDO::FETCH_ASSOC);
  if($link){
    $pdo->prepare('DELETE FROM product_media WHERE id=?')->execute([$id]);
    $q=$pdo->prepare('SELECT COUNT(*) FROM product_media WHERE media_id=?');
    $q->execute([(int)$link['media_id']]);
    if((int)$q->fetchColumn()===0){
      $q=$pdo->prepare('SELECT path FROM media WHERE id=?');
      $q->execute([(int)$link['media_id']]);$path=$q->fetchColumn();
      if($path&&is_file(dirname(__DIR__).'/'.$path))@unlink(dirname(__DIR__).'/'.$path);
      $pdo->prepare('DELETE FROM media WHERE id=?')->execute([(int)$link['media_id']]);
    }
  }
}
header('Location:index.php?tab=products&edit_product='.(int)$row['product_id'].'&saved=1');
