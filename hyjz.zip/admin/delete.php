<?php
require_once __DIR__.'/../inc/auth.php';require_admin();verify_csrf_get();
$pdo=db();$type=$_GET['type']??'';$id=(int)($_GET['id']??0);
$allowed=['product'=>'products','gallery'=>'gallery','slide'=>'slides','mobile_slide'=>'mobile_slides','article'=>'articles','media'=>'media','category'=>'categories','application'=>'applications','resource'=>'resources'];
if(!isset($allowed[$type])||$id<1){http_response_code(400);exit('Invalid delete request.');}
$t=$allowed[$type];$q=$pdo->prepare("SELECT * FROM {$t} WHERE id=?");$q->execute([$id]);$r=$q->fetch();
if(!$r){header('Location:index.php?tab=dashboard');exit;}
try{
 if($type==='category'){
   $child=(int)$pdo->prepare('SELECT COUNT(*) FROM categories WHERE parent_id=?')->execute([$id]);
   $st=$pdo->prepare('SELECT COUNT(*) FROM categories WHERE parent_id=?');$st->execute([$id]);
   if((int)$st->fetchColumn()>0){header('Location:index.php?tab=categories&error=has_children');exit;}
   $st=$pdo->prepare('SELECT COUNT(*) FROM products WHERE category_id=?');$st->execute([$id]);
   if((int)$st->fetchColumn()>0){header('Location:index.php?tab=categories&error=has_products');exit;}
 }
 if($type==='application')$pdo->prepare('DELETE FROM application_products WHERE application_id=?')->execute([$id]);
 if($type==='product'){
   $pm=$pdo->prepare('SELECT media_id FROM product_media WHERE product_id=?');$pm->execute([$id]);$mediaIds=$pm->fetchAll(PDO::FETCH_COLUMN);
   $pdo->prepare('DELETE FROM product_media WHERE product_id=?')->execute([$id]);
   $pdo->prepare('DELETE FROM rfq_items WHERE product_id=?')->execute([$id]);
   foreach($mediaIds as $mid){$chk=$pdo->prepare('SELECT COUNT(*) FROM product_media WHERE media_id=?');$chk->execute([(int)$mid]);if(!(int)$chk->fetchColumn()){$m=$pdo->prepare('SELECT path FROM media WHERE id=?');$m->execute([(int)$mid]);$path=$m->fetchColumn();if($path)@unlink(dirname(__DIR__).'/'.$path);$pdo->prepare('DELETE FROM media WHERE id=?')->execute([(int)$mid]);}}
 }
 if($type==='media'&&!empty($r['path'])){
  $mp=$r['path'];$used=0;
  foreach([['products','image'],['slides','image'],['slides','mobile_image'],['mobile_slides','image'],['mobile_slides','mobile_image'],['categories','image'],['applications','image'],['articles','image'],['gallery','image'],['resources','file'],['resources','image']] as $ref){
    $st=$pdo->prepare("SELECT COUNT(*) FROM {$ref[0]} WHERE {$ref[1]}=?");$st->execute([$mp]);$used+=(int)$st->fetchColumn();
  }
  $st=$pdo->prepare('SELECT COUNT(*) FROM product_media WHERE media_id=?');$st->execute([(int)$r['id']]);$used+=(int)$st->fetchColumn();
  $st=$pdo->prepare('SELECT COUNT(*) FROM settings WHERE value=?');$st->execute([$mp]);$used+=(int)$st->fetchColumn();
  if($used>0){header('Location:index.php?tab=media&error=in_use');exit;}
 }
 if($type==='media'&&!empty($r['path']))@unlink(dirname(__DIR__).'/'.$r['path']);
 if($type==='resource'&&!empty($r['file']))@unlink(dirname(__DIR__).'/'.$r['file']);
 if(in_array($type,['slide','mobile_slide'],true)&&!empty($r['image']))@unlink(dirname(__DIR__).'/'.$r['image']);
 if($type==='gallery'&&!empty($r['image']))@unlink(dirname(__DIR__).'/'.$r['image']);
 $pdo->prepare("DELETE FROM {$t} WHERE id=?")->execute([$id]);
}catch(Throwable $e){http_response_code(500);exit('Delete failed.');}
$dest=['product'=>'products','slide'=>'slides','mobile_slide'=>'slides','mobile_slide'=>'mobile_slides','media'=>'media','category'=>'categories','application'=>'applications','resource'=>'resources','article'=>'articles','gallery'=>'gallery'][$type]??'dashboard';
header('Location:index.php?tab='.$dest.($type==='mobile_slide'?'&device=mobile':'').'&deleted=1');exit;
