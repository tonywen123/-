<?php
require_once __DIR__.'/../inc/auth.php';
if(!empty($_SESSION['admin'])){header('Location:index.php');exit;}
$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(login_rate_limited()){$err='登录尝试次数过多，请等待15分钟后再试。';}
  else if(login_ok($_POST['username']??'',$_POST['password']??'')){login_success();header('Location:index.php');exit;}
  else{record_login_failure();$err='用户名或密码错误。';}
}
$logo=site_logo();
?><!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>鸿远网站后台登录</title><link rel="stylesheet" href="../style.css"></head><body class="admin-body"><div class="admin-wrap" style="max-width:470px;padding-top:70px"><div class="admin-card"><img src="../<?=e($logo['path'])?><?= $logo['version'] ? '?v='.e($logo['version']) : '' ?>" style="width:220px;max-height:60px;object-fit:contain" alt="Hongyuan"><h2>网站管理员</h2><?php if($err):?><p class="danger"><?=e($err)?></p><?php endif;?><form method="post"><input class="admin-input" name="username" value="admin" placeholder="用户名" autocomplete="username"><input class="admin-input" type="password" name="password" placeholder="密码" autocomplete="current-password" required><button class="btn">登录</button></form><p style="font-size:13px;color:#777">请使用网站设置中配置的管理员账号。正式上线前请修改默认密码。</p></div></div></body></html>
