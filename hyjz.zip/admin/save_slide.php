<?php
require_once __DIR__.'/../inc/auth.php';
require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST' && !isset($_GET['toggle']) && !isset($_GET['move']) && !isset($_GET['duplicate']) && !isset($_GET['clone_pc']) && !isset($_GET['reorder']))exit;
function ini_bytes($v){$v=trim((string)$v);$last=strtolower(substr($v,-1));$n=(float)$v;switch($last){case 'g':$n*=1024;case 'm':$n*=1024;case 'k':$n*=1024;}return (int)$n;}
if(empty($_POST['csrf_token']) && !empty($_SERVER['CONTENT_LENGTH']) && (int)$_SERVER['CONTENT_LENGTH']>ini_bytes(ini_get('post_max_size'))){header('Location:index.php?tab=slides&error='.rawurlencode('The banner upload is larger than the server post_max_size ('.ini_get('post_max_size').'). Increase post_max_size/upload_max_filesize, then try again.'));exit;}
if(isset($_GET['toggle'])||isset($_GET['move'])||isset($_GET['duplicate'])||isset($_GET['clone_pc'])){verify_csrf_get();}else{verify_csrf();}
$pdo=db();
if(isset($_GET['toggle'])||isset($_GET['move'])){ if(empty($_GET['csrf_token'])||empty($_SESSION['csrf'])||!hash_equals($_SESSION['csrf'],(string)$_GET['csrf_token'])){http_response_code(419);exit('Invalid action token.');} }

if(isset($_GET['reorder'])){
    $ids=$_POST['ids']??[]; if(!is_array($ids))$ids=[]; $ids=array_values(array_unique(array_map('intval',$ids)));
    $valid=[];$q=$pdo->query('SELECT id FROM slides');foreach($q as $r)$valid[(int)$r['id']]=true;
    $ids=array_values(array_filter($ids,fn($id)=>isset($valid[$id])));
    $pdo->beginTransaction(); try{foreach($ids as $i=>$sid)$pdo->prepare('UPDATE slides SET sort_order=? WHERE id=?')->execute([$i,$sid]);$pdo->commit();}catch(Throwable $e){$pdo->rollBack();http_response_code(500);exit('Reorder failed.');}
    header('Content-Type: application/json');echo json_encode(['ok'=>true]);exit;
}

if(isset($_GET['duplicate'])){
    $src=(int)$_GET['duplicate'];
    $q=$pdo->prepare('SELECT * FROM slides WHERE id=?'); $q->execute([$src]); $row=$q->fetch(PDO::FETCH_ASSOC);
    if($row){
        $newOrder=(int)$pdo->query('SELECT COALESCE(MAX(sort_order),0)+1 FROM slides')->fetchColumn();
        $cols=array_keys($row);
        $skip=['id'];
        $cols=array_values(array_filter($cols,fn($c)=>!in_array($c,$skip,true)));
        if(in_array('sort_order',$cols,true))$row['sort_order']=$newOrder;
        $namesSql=implode(',',array_map(fn($c)=>'"'.$c.'"',$cols)); $marks=implode(',',array_fill(0,count($cols),'?'));
        $pdo->prepare('INSERT INTO slides ('.$namesSql.') VALUES ('.$marks.')')->execute(array_map(fn($c)=>$row[$c],$cols));
    }
    header('Location:index.php?tab=slides'); exit;
}

if(isset($_GET['toggle'])){
    $pdo->prepare('UPDATE slides SET enabled=CASE enabled WHEN 1 THEN 0 ELSE 1 END WHERE id=?')->execute([(int)$_GET['toggle']]);
    header('Location:index.php?tab=slides'); exit;
}
if(isset($_GET['move'])){
    $id=(int)($_GET['id']??0);
    $r=$pdo->prepare('SELECT id,sort_order FROM slides WHERE id=?'); $r->execute([$id]); $row=$r->fetch(PDO::FETCH_ASSOC);
    if($row){
        $dir=$_GET['move']==='up'?-1:1;
        $arr=$pdo->query('SELECT id,sort_order FROM slides ORDER BY sort_order,id')->fetchAll(PDO::FETCH_ASSOC);
        $pos=0; foreach($arr as $i=>$x) if((int)$x['id']===$id){$pos=$i;break;}
        $np=$pos+$dir;
        if(isset($arr[$np])){
            $pdo->prepare('UPDATE slides SET sort_order=? WHERE id=?')->execute([$arr[$np]['sort_order'],$id]);
            $pdo->prepare('UPDATE slides SET sort_order=? WHERE id=?')->execute([$row['sort_order'],$arr[$np]['id']]);
        }
    }
    header('Location:index.php?tab=slides'); exit;
}

// Keep the schema compatible with older SQLite versions by adding new columns only when needed.
$cols=$pdo->query('PRAGMA table_info(slides)')->fetchAll(PDO::FETCH_ASSOC);
$names=array_column($cols,'name');
$newCols=[
    'text_x'=>'REAL DEFAULT 8', 'text_y'=>'REAL DEFAULT 50', 'title_x'=>'REAL DEFAULT 8', 'title_y'=>'REAL DEFAULT 50', 'button_x'=>'REAL DEFAULT 8', 'button_y'=>'REAL DEFAULT 78',
    'show_eyebrow'=>'INTEGER DEFAULT 1', 'show_title'=>'INTEGER DEFAULT 1', 'eyebrow_size'=>'REAL DEFAULT 12', 'eyebrow_color'=>"TEXT DEFAULT '#555d64'",
    'title_size'=>'REAL DEFAULT 64', 'title_color'=>"TEXT DEFAULT '#14181d'",
    'desc_size'=>'REAL DEFAULT 16', 'desc_color'=>"TEXT DEFAULT '#555d64'",
    'button_font_size'=>'REAL DEFAULT 12', 'button_text_color'=>"TEXT DEFAULT '#ffffff'",
    'button_bg_color'=>"TEXT DEFAULT '#c8232d'", 'button_border_color'=>"TEXT DEFAULT '#c8232d'",
    'button_width'=>'REAL DEFAULT 180', 'button_height'=>'REAL DEFAULT 46', 'button_radius'=>'REAL DEFAULT 0', 'text_width'=>'REAL DEFAULT 620', 'text_align'=>"TEXT DEFAULT 'left'", 'image_fit'=>"TEXT DEFAULT 'fill'", 'image_position'=>"TEXT DEFAULT 'center center'", 'overlay_enabled'=>'INTEGER DEFAULT 0', 'link_target'=>"TEXT DEFAULT '_self'", 'mobile_image'=>"TEXT DEFAULT ''", 'alt_text'=>"TEXT DEFAULT ''", 'overlay_color'=>"TEXT DEFAULT '#000000'", 'overlay_opacity'=>'REAL DEFAULT 0.35', 'eyebrow_font'=>"TEXT DEFAULT 'Inter'", 'title_font'=>"TEXT DEFAULT 'Inter'", 'desc_font'=>"TEXT DEFAULT 'Inter'", 'button_font'=>"TEXT DEFAULT 'Inter'", 'eyebrow_weight'=>'INTEGER DEFAULT 600', 'title_weight'=>'INTEGER DEFAULT 700', 'desc_weight'=>'INTEGER DEFAULT 400', 'button_weight'=>'INTEGER DEFAULT 700', 'eyebrow_letter_spacing'=>"TEXT DEFAULT '.14em'", 'title_letter_spacing'=>"TEXT DEFAULT '-.03em'", 'desc_letter_spacing'=>"TEXT DEFAULT '0'", 'button_letter_spacing'=>"TEXT DEFAULT '.05em'", 'eyebrow_line_height'=>'REAL DEFAULT 1.2', 'title_line_height'=>'REAL DEFAULT 1.02', 'desc_line_height'=>'REAL DEFAULT 1.45', 'button_line_height'=>'REAL DEFAULT 1.2'
];
foreach($newCols as $name=>$definition){
    if(!in_array($name,$names,true)) $pdo->exec('ALTER TABLE slides ADD COLUMN '.$name.' '.$definition);
}

$id=(int)($_POST['id']??0);
$overlayColor=$_POST['overlay_color']??'#000000';
$overlayColor=preg_match('/^#[0-9a-fA-F]{6}$/',(string)$overlayColor)?$overlayColor:'#000000';
$overlayOpacity=max(0,min(1,(float)($_POST['overlay_opacity']??0.35)));
$title=trim($_POST['title']??'');
$subtitle=trim($_POST['subtitle']??'');
$text=trim($_POST['text']??'');
$button=trim($_POST['button_text']??'View Products');
$url=trim($_POST['button_url']??'products.php');
$sort=(int)($_POST['sort_order']??0);
$enabled=!empty($_POST['enabled'])?1:0;

$textX=max(0,min(100,(float)($_POST['text_x']??8)));
$textY=max(0,min(100,(float)($_POST['text_y']??50)));
$buttonX=max(0,min(100,(float)($_POST['button_x']??8)));
$buttonY=max(0,min(100,(float)($_POST['button_y']??78)));
$showEyebrow=!isset($_POST['show_eyebrow'])||$_POST['show_eyebrow']!=='0';$showTitle=!isset($_POST['show_title'])||$_POST['show_title']!=='0';$eyebrowSize=max(4,min(120,(float)($_POST['eyebrow_size']??12)));
$titleSize=max(8,min(220,(float)($_POST['title_size']??64)));
$descSize=max(6,min(80,(float)($_POST['desc_size']??16)));
$buttonFontSize=max(6,min(48,(float)($_POST['button_font_size']??12)));
$buttonWidth=max(60,min(1400,(float)($_POST['button_width']??180)));
$buttonHeight=max(24,min(180,(float)($_POST['button_height']??46)));
$buttonRadius=max(0,min(90,(float)($_POST['button_radius']??0)));
$textWidth=max(120,min(1600,(float)($_POST['text_width']??620)));
$textAlign=in_array($_POST['text_align']??'left',['left','center','right'],true)?$_POST['text_align']:'left';
$imageFit=in_array($_POST['image_fit']??'fill',['fill','cover','contain'],true)?$_POST['image_fit']:'fill';
$imagePosition=trim((string)($_POST['image_position']??'center center'));$overlayEnabled=!empty($_POST['overlay_enabled'])?1:0;$linkTarget=($_POST['link_target']??'_self')==='_blank'?'_blank':'_self';$altText=trim($_POST['alt_text']??$title);$mobileImage='';
if(!preg_match('/^(left|center|right)\s+(top|center|bottom)$/',$imagePosition))$imagePosition='center center';
$hex=function($v,$fallback){$v=trim((string)$v);return preg_match('/^#[0-9a-fA-F]{6}$/',$v)?$v:$fallback;};
$eyebrowColor=$hex($_POST['eyebrow_color']??'','#555d64');
$titleColor=$hex($_POST['title_color']??'','#14181d');
$descColor=$hex($_POST['desc_color']??'','#555d64');
$buttonTextColor=$hex($_POST['button_text_color']??'','#ffffff');
$buttonBgColor=$hex($_POST['button_bg_color']??'','#c8232d');
$buttonBorderColor=$hex($_POST['button_border_color']??'','#c8232d');$fontAllow=['Inter','Roboto','Montserrat','Poppins','Open Sans','Lato','Oswald','Source Sans 3','Noto Sans','Noto Sans SC','Noto Sans JP','DM Sans','Manrope','Raleway','Work Sans','Nunito Sans'];
$font=function($v,$fallback='Inter')use($fontAllow){$v=trim((string)$v);return in_array($v,$fontAllow,true)?$v:$fallback;};
$weight=function($v,$fallback){$v=(int)$v;return in_array($v,[300,400,500,600,700,800],true)?$v:$fallback;};
$ls=function($v,$fallback){$v=trim((string)$v);return preg_match('/^-?(?:\d+(?:\.\d+)?)(?:px|em|rem|%)?$/',$v)?$v:$fallback;};
$lh=function($v,$fallback){$v=trim((string)$v);return preg_match('/^(?:normal|(?:\d+(?:\.\d+)?|\.\d+)(?:px|em|rem|%|vw|vh)?)$/',$v)?$v:$fallback;};
$eyebrowFont=$font($_POST['eyebrow_font']??'Inter');$titleFont=$font($_POST['title_font']??'Inter');$descFont=$font($_POST['desc_font']??'Inter');$buttonFont=$font($_POST['button_font']??'Inter');
$eyebrowWeight=$weight($_POST['eyebrow_weight']??600,600);$titleWeight=$weight($_POST['title_weight']??700,700);$descWeight=$weight($_POST['desc_weight']??400,400);$buttonWeight=$weight($_POST['button_weight']??700,700);
$eyebrowLetter=$ls($_POST['eyebrow_letter_spacing']??'.14em','.14em');$titleLetter=$ls($_POST['title_letter_spacing']??'-.03em','-.03em');$descLetter=$ls($_POST['desc_letter_spacing']??'0','0');$buttonLetter=$ls($_POST['button_letter_spacing']??'.05em','.05em');
$eyebrowLine=$lh($_POST['eyebrow_line_height']??1.2,1.2);$titleLine=$lh($_POST['title_line_height']??1.02,1.02);$descLine=$lh($_POST['desc_line_height']??1.45,1.45);$buttonLine=$lh($_POST['button_line_height']??1.2,1.2);

$image='';
if($id){$q=$pdo->prepare('SELECT image FROM slides WHERE id=?');$q->execute([$id]);$image=(string)$q->fetchColumn();}
if(isset($_FILES['image_file']) && (int)($_FILES['image_file']['error'] ?? UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_NO_FILE){
    $uploadErr=(int)$_FILES['image_file']['error'];
    if($uploadErr!==UPLOAD_ERR_OK){
        $map=[UPLOAD_ERR_INI_SIZE=>'The banner is larger than PHP upload_max_filesize ('.ini_get('upload_max_filesize').').',UPLOAD_ERR_FORM_SIZE=>'The banner exceeds the form upload limit.',UPLOAD_ERR_PARTIAL=>'The banner upload was interrupted. Please try again.',UPLOAD_ERR_NO_TMP_DIR=>'PHP temporary upload directory is unavailable.',UPLOAD_ERR_CANT_WRITE=>'The server could not write the uploaded banner.',UPLOAD_ERR_EXTENSION=>'A PHP extension stopped the banner upload.'];
        header('Location:index.php?tab=slides'.($id?'&edit_slide='.$id:'').'&error='.rawurlencode($map[$uploadErr]??'The banner upload failed with PHP error '.$uploadErr.'.'));exit;
    }
    $f=$_FILES['image_file'];
    if((int)$f['size']>30*1024*1024){header('Location:index.php?tab=slides'.($id?'&edit_slide='.$id:'').'&error='.rawurlencode('Banner is too large. Maximum supported size is 30 MB.'));exit;}
    $mime=detect_upload_mime($f['tmp_name'],$f['name']);$allowed=['image/jpeg','image/png','image/webp','image/gif'];
    if(!in_array($mime,$allowed,true)){header('Location:index.php?tab=slides'.($id?'&edit_slide='.$id:'').'&error='.rawurlencode('Unsupported banner format (detected '.$mime.'). Use JPG, PNG, WEBP or GIF.'));exit;}
    $info=@getimagesize($f['tmp_name']);
    if(!$info||empty($info[0])||empty($info[1])){header('Location:index.php?tab=slides'.($id?'&edit_slide='.$id:'').'&error='.rawurlencode('The selected banner is not a readable image.'));exit;}
    if($info[0]>12000||$info[1]>12000){header('Location:index.php?tab=slides'.($id?'&edit_slide='.$id:'').'&error='.rawurlencode('Banner dimensions exceed the 12000 px safety limit.'));exit;}
    $im=upload_file('image_file','uploads/slides',$allowed);
    if(!$im){header('Location:index.php?tab=slides'.($id?'&edit_slide='.$id:'').'&error='.rawurlencode('The banner passed validation but the server could not store it. Check write permission for uploads/slides.'));exit;}
    $image=$im['path'];$pdo->prepare('INSERT INTO media(filename,path,mime,size) VALUES(?,?,?,?)')->execute([$im['filename'],$im['path'],$im['mime'],$im['size']]);
}
$oldMobile='';if($id){$q=$pdo->prepare('SELECT mobile_image FROM slides WHERE id=?');$q->execute([$id]);$oldMobile=(string)$q->fetchColumn();}$mobileImage=$oldMobile;$mobi=upload_file('mobile_image_file','uploads/slides',['image/jpeg','image/png','image/webp']);if($mobi){$mobileImage=$mobi['path'];$pdo->prepare('INSERT INTO media(filename,path,mime,size) VALUES(?,?,?,?)')->execute([$mobi['filename'],$mobi['path'],$mobi['mime'],$mobi['size']]);}
if(!$image){ header('Location:index.php?tab=slides&error='.rawurlencode('Please select a desktop banner image.')); exit; }

$values=[$title,$subtitle,$text,$button,$url,$image,$sort,$enabled,$showEyebrow?1:0,$showTitle?1:0,$textX,$textY,$titleX,$titleY,$buttonX,$buttonY,$eyebrowSize,$eyebrowColor,$titleSize,$titleColor,$descSize,$descColor,$buttonFontSize,$buttonTextColor,$buttonBgColor,$buttonBorderColor,$buttonWidth,$buttonHeight,$buttonRadius,$textWidth,$textAlign,$imageFit,$imagePosition,$overlayEnabled,$overlayColor,$overlayOpacity,$linkTarget,$mobileImage,$altText,$eyebrowFont,$titleFont,$descFont,$buttonFont,$eyebrowWeight,$titleWeight,$descWeight,$buttonWeight,$eyebrowLetter,$titleLetter,$descLetter,$buttonLetter,$eyebrowLine,$titleLine,$descLine,$buttonLine];
if($id){
    $values[]=$id;
    $pdo->prepare('UPDATE slides SET title=?,subtitle=?,text=?,button_text=?,button_url=?,image=?,sort_order=?,enabled=?,show_eyebrow=?,show_title=?,text_x=?,text_y=?,title_x=?,title_y=?,button_x=?,button_y=?,eyebrow_size=?,eyebrow_color=?,title_size=?,title_color=?,desc_size=?,desc_color=?,button_font_size=?,button_text_color=?,button_bg_color=?,button_border_color=?,button_width=?,button_height=?,button_radius=?,text_width=?,text_align=?,image_fit=?,image_position=?,overlay_enabled=?,overlay_color=?,overlay_opacity=?,link_target=?,mobile_image=?,alt_text=?,eyebrow_font=?,title_font=?,desc_font=?,button_font=?,eyebrow_weight=?,title_weight=?,desc_weight=?,button_weight=?,eyebrow_letter_spacing=?,title_letter_spacing=?,desc_letter_spacing=?,button_letter_spacing=?,eyebrow_line_height=?,title_line_height=?,desc_line_height=?,button_line_height=? WHERE id=?')->execute($values);
}else{
    $pdo->prepare('INSERT INTO slides(title,subtitle,text,button_text,button_url,image,sort_order,enabled,show_eyebrow,show_title,text_x,text_y,title_x,title_y,button_x,button_y,eyebrow_size,eyebrow_color,title_size,title_color,desc_size,desc_color,button_font_size,button_text_color,button_bg_color,button_border_color,button_width,button_height,button_radius,text_width,text_align,image_fit,image_position,overlay_enabled,overlay_color,overlay_opacity,link_target,mobile_image,alt_text,eyebrow_font,title_font,desc_font,button_font,eyebrow_weight,title_weight,desc_weight,button_weight,eyebrow_letter_spacing,title_letter_spacing,desc_letter_spacing,button_letter_spacing,eyebrow_line_height,title_line_height,desc_line_height,button_line_height) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')->execute($values);
}
header('Location:index.php?tab=slides&saved=1');
