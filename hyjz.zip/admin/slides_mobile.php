<?php
$mobileSettingsCurrent=[];
if(!empty($editSlide['mobile_settings'])){ $tmpMobile=json_decode($editSlide['mobile_settings'],true); if(is_array($tmpMobile))$mobileSettingsCurrent=$tmpMobile; }
$mobileImage=(string)($editSlide['mobile_image']??'');
$previewImage=$mobileImage?:((string)($editSlide['image']??''));
$mobileHas=$mobileImage!=='';
?>
<div class="head"><div><h1>Hero Carousel · Mobile</h1><div class="muted">Mobile is a completely independent editor. Nothing here changes the PC banner.</div></div><div class="toolbar"><span class="pill"><?=count($slides)?> slides</span><a class="btn light small" href="?tab=slides&mode=pc">PC端</a><a class="btn small" href="?tab=slides&mode=workbench">工作台</a></div></div>
<div class="panel hero-mode-banner"><div><b>移动端独立编辑</b><span>每张 Banner 的 Mobile 图片、文字、位置、字体、按钮和覆盖层单独保存。PC 端和移动端互不覆盖。</span></div></div>
<div class="panel"><h2>选择 Banner</h2><div class="slide-mode-list"><?php foreach($slides as $s): ?><a class="slide-mode-item <?=((int)($editSlide['id']??0)===(int)$s['id']?'active':'')?>" href="?tab=slides&mode=mobile&edit_slide=<?=$s['id']?>"><div><?php if(!empty($s['mobile_image'])):?><img src="../<?=e($s['mobile_image'])?>" alt=""><?php else:?><div class="slide-mode-empty">NO MOBILE</div><?php endif;?></div><span><b><?=e($s['title']?:'Untitled slide')?></b><small>Slide #<?=e($s['id'])?> · <?=!empty($s['mobile_image'])?'Mobile ready':'Uses PC fallback'?></small></span></a><?php endforeach; if(!$slides):?><div class="empty">No slides yet. Create the PC banner first.</div><?php endif;?></div></div>
<?php if($editSlide): ?>
<div class="panel mobile-editor-shell">
  <div class="mobile-editor-top"><div><h2 style="margin:0">Mobile Editor</h2><div class="muted">1080 × 1350 working canvas · all PC element controls are available in the Mobile Workbench.</div></div><button type="button" class="btn" id="openMobileWorkbench">Open Mobile Workbench</button></div>
  <form action="save_slide_mobile.php" method="post" enctype="multipart/form-data" id="slideForm"><?=csrf_field()?><input type="hidden" name="id" value="<?=e($editSlide['id'])?>"><input type="hidden" name="mobile_settings" id="mobileSettingsInput" value="<?=e(json_encode($mobileSettingsCurrent,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?>">
    <input type="hidden" name="title" value="<?=e($editSlide['title']??'')?>"><input type="hidden" name="text" value="<?=e($editSlide['text']??'')?>"><input type="hidden" name="button_text" value="<?=e($editSlide['button_text']??'View Products')?>"><input type="hidden" name="button_url" value="<?=e($editSlide['button_url']??'products.php')?>"><div class="mobile-current-grid"><div><label class="field-label">Current Mobile Banner</label><div class="mobile-current-preview"><?php if($previewImage):?><img id="mobileCurrentImage" src="../<?=e($previewImage)?>" alt="Mobile banner preview"><?php else:?><div>No image</div><?php endif;?></div><div class="hint"><?=$mobileHas?'独立 Mobile 图片':'目前使用 PC Banner 作为手机端回退图'?></div></div><div><div class="mobile-feature-list"><b>独立能力</b><span>Background / Eyebrow / Title / Description / Button / Text Group</span><span>位置、字号、字体、颜色、行高、按钮样式、覆盖层全部独立保存</span><span>支持拖动、撤销、重做、缩放、最小化、最大化、预览和保存</span></div><div class="toolbar" style="margin-top:18px"><button type="button" class="btn" id="openMobileWorkbench2">Open Mobile Workbench</button></div></div></div>
  </form>
</div>
<div style="display:none"><img id="layoutBg" src="../<?=e($previewImage)?>" alt=""><input id="quickEyebrowText" value="<?=e($editSlide['subtitle']??'GLOBAL ADVERTISING MATERIALS')?>"></div>
<?php include __DIR__.'/mobile_workbench_fragment.php'; ?>
<link rel="stylesheet" href="mobile_workbench.css"><script src="mobile_workbench.js"></script>
<script>(function(){var b=document.getElementById('openMobileWorkbench2'),a=document.getElementById('openMobileWorkbench');if(b&&a)b.addEventListener('click',function(){a.click()});var out=document.getElementById('mwImageFile'),outside=document.getElementById('mwImageFileOutside');if(out&&outside)outside.addEventListener('change',function(){if(this.files&&this.files[0]){try{var dt=new DataTransfer();dt.items.add(this.files[0]);out.files=dt.files;out.dispatchEvent(new Event('change',{bubbles:true}))}catch(e){out.value=''}}});var rem=document.getElementById('removeMobileOutside'),mwrem=document.getElementById('mwRemoveImage');if(rem&&mwrem)rem.addEventListener('change',function(){mwrem.checked=this.checked;mwrem.dispatchEvent(new Event('change',{bubbles:true}))});})();</script>
<?php else: ?>
<div class="panel empty">Select a banner above to edit its Mobile version.</div>
<?php endif; ?>
