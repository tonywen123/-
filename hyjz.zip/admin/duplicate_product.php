<?php
require_once __DIR__.'/../inc/auth.php'; require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405); exit('Method not allowed'); }
verify_csrf();
$pdo=db(); $id=(int)($_POST['id']??0);
$q=$pdo->prepare('SELECT * FROM products WHERE id=?'); $q->execute([$id]); $p=$q->fetch(PDO::FETCH_ASSOC);
if(!$p){ header('Location:index.php?tab=products&error=notfound'); exit; }
$base=$p['slug']?:slugify($p['name']); $slug=$base.'-copy'; $n=2;
while(true){$s=$pdo->prepare('SELECT COUNT(*) FROM products WHERE slug=?');$s->execute([$slug]);if(!(int)$s->fetchColumn())break;$slug=$base.'-copy-'.$n++;}
$sql='INSERT INTO products(name,slug,category,description,overview,applications,specs,image,pdf,sort_order,featured,seo_title,seo_description,category_id,published,sku,image_alt,model,spec_rows,meta_keywords,video_url,sample_available,featured_label) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
$st=$pdo->prepare($sql);$st->execute([
 $p['name'].' (Copy)',$slug,$p['category'],$p['description'],$p['overview'],$p['applications'],$p['specs'],$p['image'],$p['pdf'],(int)$p['sort_order']+1,(int)$p['featured'],$p['seo_title'],$p['seo_description'],$p['category_id'],0,$p['sku']?:'',$p['image_alt']?:$p['name'],$p['model']??'',$p['spec_rows']??'',$p['meta_keywords']??'',$p['video_url']??'',$p['sample_available']??0,$p['featured_label']??''
]);
$newId=(int)$pdo->lastInsertId();
$gm=$pdo->prepare('SELECT media_id,sort_order FROM product_media WHERE product_id=? ORDER BY sort_order,id');$gm->execute([$id]);$ins=$pdo->prepare('INSERT INTO product_media(product_id,media_id,sort_order) VALUES(?,?,?)');foreach($gm as $g)$ins->execute([$newId,(int)$g['media_id'],(int)$g['sort_order']]);
header('Location:index.php?tab=products&edit_product='.$newId.'&duplicated=1');exit;
