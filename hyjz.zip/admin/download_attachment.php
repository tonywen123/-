<?php
require_once __DIR__.'/../inc/auth.php';require_admin();
$id=(int)($_GET['id']??0);$q=db()->prepare('SELECT attachment FROM inquiries WHERE id=?');$q->execute([$id]);$path=$q->fetchColumn();
if(!$path||strpos($path,'uploads/rfq/')!==0){http_response_code(404);exit('Attachment not found.');}
$file=dirname(__DIR__).'/'.$path;if(!is_file($file)){http_response_code(404);exit('Attachment not found.');}
$mime=detect_upload_mime($file,basename($file));$mime=$mime?:'application/octet-stream';header('Content-Type: '.$mime);header('Content-Length: '.filesize($file));header('Content-Disposition: attachment; filename="'.basename($file).'"');readfile($file);exit;
