<?php
require_once __DIR__.'/../inc/auth.php';
require_admin();if($_SERVER['REQUEST_METHOD']==='POST')verify_csrf();
$pdo=db();

$fields=['site_name','company_name','hero_eyebrow','hero_title','hero_subtitle','hero_text','hero_cta','hero_cta_url','show_categories','about_title','about_text','about_cta','about_image','email','whatsapp','phone','address','footer_text','facebook','linkedin','instagram','youtube','ga_id','pixel_id','notify_email','seo_title','seo_description','hero_height','hero_mobile_height','hero_transition','hero_autoplay','site_keywords','default_og_image','default_language','admin_username','font_body','font_heading','font_nav','font_button','font_eyebrow','font_custom_css_url','font_body_size','font_body_weight','font_body_color','font_body_letter_spacing','font_body_line_height','font_heading_weight','font_heading_letter_spacing','font_heading_line_height','font_nav_weight','font_nav_letter_spacing','font_button_weight','font_button_letter_spacing','font_eyebrow_weight','font_eyebrow_letter_spacing','logo_width','logo_height','logo_mobile_width','logo_mobile_height'];
foreach($fields as $k){
    if(array_key_exists($k,$_POST)){
        $v=in_array($k,['about_text','footer_text','hero_text'],true)?rich_text_clean($_POST[$k]):trim((string)$_POST[$k]);
        save_setting($k,$v);
    }
}

if(!empty($_POST['admin_password'])){
    $pw=(string)$_POST['admin_password'];
    if(strlen($pw)>=10){ save_setting('admin_password_hash',password_hash($pw,PASSWORD_DEFAULT)); save_setting('admin_password',''); }
}

$logoError='';
if(!empty($_POST['reset_logo'])){
    save_setting('logo_path','assets/logo-default.png');
}else if(!empty($_FILES['logo_file']['tmp_name'])){
    $f=$_FILES['logo_file'];
    if($f['error']!==UPLOAD_ERR_OK){
        $logoError='Logo upload failed.';
    }elseif($f['size']>5*1024*1024){
        $logoError='Logo is too large. Maximum size is 5 MB.';
    }else{
        $mime=detect_upload_mime($f['tmp_name'],$f['name']);
        $allowed=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];
        if(!isset($allowed[$mime])){
            $logoError='Only PNG, JPG and WEBP logos are allowed.';
        }else{
            $dir=dirname(__DIR__).'/uploads/logo';
            if(!is_dir($dir) && !mkdir($dir,0755,true) && !is_dir($dir)){
                $logoError='The logo upload directory could not be created.';
            }elseif(!is_writable($dir)){
                $logoError='The logo upload directory is not writable by PHP.';
            }
            if(!$logoError){
                $name='logo_'.date('YmdHis').'_'.bin2hex(random_bytes(6)).'.'.$allowed[$mime];
                $target=$dir.'/'.$name;
                if(!move_uploaded_file($f['tmp_name'],$target)){
                    $logoError='The server could not save the logo file.';
                }else{
                    $path='uploads/logo/'.$name;
                    save_setting('logo_path',$path);
                    $pdo->prepare('INSERT INTO media(filename,path,mime,size) VALUES(?,?,?,?)')->execute([$f['name'],$path,$mime,$f['size']]);
                }
            }
        }
    }
}

$tab=isset($_POST['homepage_only'])?'homepage':'settings';
$qs='&saved=1';
if($logoError) $qs.='&logo_error='.rawurlencode($logoError);
header('Location:index.php?tab='.$tab.$qs);
exit;
