# Hongyuan V14.4.9

Targeted change only:
- Mobile Hero Carousel editing canvas changed from 1080 × 1350 to 1080 × 600.
- Mobile public hero display ratio changed to 1080:600 (9:5) on mobile widths.
- PC carousel records, ordering, editing flow, workbench functions, and existing database/uploads are not migrated or deleted.
- Package intentionally excludes `data.sqlite` and `uploads/`.

Base: V14.4.x safe package currently available in the working library.
