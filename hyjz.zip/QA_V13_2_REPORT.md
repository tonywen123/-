# Hongyuan V13.2 QA Report

## UI changes
- Removed the obsolete horizontal Banner / Eyebrow / Title / Description / Button / Text Block / Background strip.
- Replaced the old right-side property rail with a true floating Photoshop-style workbench window.
- Floating workbench is draggable, minimizable, closable with Esc, and resizable from the bottom-right corner.
- Canvas remains full width and is not pushed aside by editor controls.
- Element controls are presented as compact cards inside the floating window.
- Added responsive behavior for desktop and mobile.
- Added admin visual polish: active navigation states, hover feedback, panel/card elevation, focus states, responsive spacing and dashboard interaction cues.

## Functional QA
- PHP lint: all PHP files passed.
- Static QA: 180 PASS / 0 FAIL / 0 WARN.
- DB workflow QA: 15 PASS.
- Repeated 5 times: each run 180 PASS / 0 FAIL / 0 WARN and 15 DB workflow PASS.
- Banner upload handler was inspected for PHP upload errors, MIME validation, image readability, dimensions, storage failures and post/upload size limits.

## Deployment note
The code-level QA cannot log into a customer's production server. After deployment, verify one real Hero Carousel upload on the production PHP host.
