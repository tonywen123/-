<?php
require_once __DIR__.'/db.php';
function require_admin(){
    if(empty($_SESSION['admin'])){header('Location: login.php');exit;}
    if(empty($_SESSION['admin_last_seen'])) $_SESSION['admin_last_seen']=time();
    if(time()-(int)$_SESSION['admin_last_seen']>8*3600){unset($_SESSION['admin'],$_SESSION['admin_last_seen']);header('Location: login.php?expired=1');exit;}
    $_SESSION['admin_last_seen']=time();
}
function admin_password_ok($stored,$plain){
    if(!$stored) return hash_equals('admin123',$plain);
    if(str_starts_with($stored,'$2y$')||str_starts_with($stored,'$argon2')) return password_verify($plain,$stored);
    return hash_equals($stored,$plain);
}
function login_ok($u,$p){
    if(!hash_equals((string)setting('admin_username','admin'),(string)$u)) return false;
    if(!admin_password_ok((string)setting('admin_password_hash',''),$p)) return false;
    // Legacy plaintext password is upgraded after a successful login.
    $legacy=(string)setting('admin_password','');
    if(!setting('admin_password_hash','')){
        $candidate=$legacy!==''?$legacy:'admin123';
        if(hash_equals($candidate,$p)){
            save_setting('admin_password_hash',password_hash($p,PASSWORD_DEFAULT));
            save_setting('admin_password','');
        }
    }
    return true;
}
function login_rate_limited(){
    $now=time();$window=15*60;
    if(!isset($_SESSION['login_attempts'])) $_SESSION['login_attempts']=[];
    $_SESSION['login_attempts']=array_values(array_filter($_SESSION['login_attempts'],fn($t)=>($now-$t)<$window));
    return count($_SESSION['login_attempts'])>=6;
}
function record_login_failure(){$_SESSION['login_attempts'][]=time();}
function login_success(){session_regenerate_id(true);$_SESSION['admin']=1;$_SESSION['admin_last_seen']=time();unset($_SESSION['login_attempts']);}
function logout_admin(){$_SESSION=[];if(ini_get('session.use_cookies')){$p=session_get_cookie_params();setcookie(session_name(),'',['expires'=>time()-42000,'path'=>$p['path'],'domain'=>$p['domain'],'secure'=>$p['secure'],'httponly'=>$p['httponly'],'samesite'=>$p['samesite']??'Lax']);}session_destroy();}
?>
