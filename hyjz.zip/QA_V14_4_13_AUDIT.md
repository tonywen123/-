# Hongyuan V14.4.13 Audit / QA

## Benchmark scope
Compared the current Hongyuan structure against current public workflows from major graphics-material manufacturers: Avery Dennison, 3M Graphics & Signage, ORAFOL, Arlon Graphics, HEXIS Graphics, Mactac, Metamark and General Formulations.

Useful patterns found repeatedly:
- Product Finder/search by product family and application/specification.
- Product detail pages with structured specifications and technical downloads.
- Multiple technical resources per product/family: TDS, SDS/MSDS, certificates, application guides, ICC profiles, warranties and other bulletins.
- Application-oriented navigation that connects applications to products.
- Comparison/filtering where it materially helps product selection.
- Buyer-facing RFQ/sample/contact paths rather than unnecessary e-commerce features.

## Hongyuan changes in this pass
1. Fixed rich-text cleanup so empty `<span></span>` nodes and entity-encoded span tags cannot appear as visible text in homepage/category/resource cards.
2. Added plain-text normalization for card/list descriptions while keeping rich text available in appropriate detail areas.
3. Expanded resource uploads beyond images/PDF to DOC/DOCX/XLS/XLSX/PPT/PPTX with extension-aware MIME handling for office ZIP containers.
4. Added upload-failure handling for resource files and product TDS uploads instead of silently saving an unusable record.
5. Added a CSRF refresh endpoint and submit-time token refresh for admin POST forms to reduce stale-form token failures.
6. Technical Resources can be filtered by related product; one product can have multiple resource records, so multiple certificates/TDS/MSDS/reports are supported without a schema migration.
7. Product edit now exposes existing gallery images for reorder/delete without replacing the existing product data model.
8. Product directory main/subcategories now expose quick up/down ordering controls.
9. Site search suggestions now cover products, applications, resources and news instead of products only.
10. Major admin navigation/actions/labels were localized to practical Chinese wording; internal database status values remain unchanged where compatibility matters.
11. Product detail resource display was increased from 6 to 12 related resources.
12. Safe-package rule retained: no `data.sqlite`, no `uploads/`.

## Tests performed in this environment
- PHP syntax lint: all PHP files passed.
- Local-reference scan: no obvious missing local PHP/CSS/JS references.
- Runtime helper test: rich-text sanitization removes empty spans; office/PDF MIME fallback resolves correctly.
- Feature checks: mobile hero 1080x600 logic retained; device-based mobile switch retained; safe package contains no database/uploads.
- Code-level workflow inspection: admin form actions, CSRF fields, upload endpoints, resource download route, product/resource/application relationships, search routes and product-media routes were checked for matching files and parameters.

## Important limitation
This environment does not have the PHP SQLite PDO driver and does not contain the production database/uploads, so a true logged-in browser test against the user's live database cannot be honestly claimed here. The package was therefore validated by PHP lint, runtime helper tests, route/reference checks and code-level workflow inspection. Live production data was not modified.
