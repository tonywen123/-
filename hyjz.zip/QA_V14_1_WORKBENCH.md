# V14.1 Workbench QA

- Replaced the previous stacked/experimental floating-workbench implementations with one isolated implementation.
- Floating window is moved to document body and form controls retain `form=slideForm`.
- 8-way resize handles: N/S/E/W/NE/NW/SE/SW.
- Document-level pointer drag for mouse/pen/touch.
- Minimize, maximize/restore, close, Esc, persistent position/size.
- Layers: select, visual lock state, grid, snap toggle, alignment shortcuts, keyboard nudge.
- Undo/redo, Ctrl/Cmd+S, reset, preview and save retained.
- Existing admin modules and core visual-editor scripts retained.
