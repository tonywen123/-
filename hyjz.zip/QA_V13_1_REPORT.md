# Hongyuan V13.1 QA Report

## Scope
- Rebased directly on `Hongyuan_FINAL_V13.zip`.
- Converted the Hero Carousel property editor from a right-side rail into a Photoshop-style floating workbench window.
- Kept the live 1920 × 530 canvas full-width.
- Added open / close / minimize behavior, draggable floating window, Escape-to-close, and direct canvas selection.
- Fixed the V13 workbench slider binding so repeated panel openings do not stack duplicate event listeners.
- Hardened Hero Carousel upload handling with actionable error messages for PHP upload limits, partial uploads, MIME mismatch, unreadable images, oversized dimensions, and storage permission failures.
- Raised the internal upload guard from 20 MB to 30 MB to match the included 32 MB PHP upload configuration.
- Added GIF support to Hero Carousel desktop/mobile image selectors.

## Automated QA
- PHP syntax: `admin/index.php` PASS
- PHP syntax: `admin/save_slide.php` PASS
- PHP syntax: `inc/db.php` PASS
- Embedded JavaScript syntax checks: PASS
- Existing static QA suite: **180 PASS / 0 FAIL / 0 WARN** per run
- Static QA repeated **10 consecutive runs**: PASS
- Database workflow suite: **15 PASS**
- Included SQLite integrity/schema workflow checks: PASS

## Upload smoke tests
A standalone local HTTP upload harness using the same MIME/dimension/storage rules was exercised repeatedly with 1920 × 530 test images:
- JPG: PASS
- PNG: PASS
- WEBP: PASS
- GIF: PASS

## Important deployment note
The package includes `.user.ini` with:
- `upload_max_filesize=32M`
- `post_max_size=40M`
- `memory_limit=256M`

The final PHP upload guard accepts banners up to 30 MB, leaving headroom for multipart form overhead.

## Manual production test recommended after deployment
1. Log in to Admin → Hero Carousel.
2. Upload a JPG/PNG/WEBP banner and save.
3. Edit the same slide and replace the image.
4. Open the floating workbench, drag text/button, change size, close/minimize, reopen, and save.
5. Toggle overlay off and verify the public hero has no artificial black mask.
6. Repeat with a second banner.
7. Check the public homepage after saving and verify the new image and text positions.
