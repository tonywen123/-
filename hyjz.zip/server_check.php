<?php
require_once __DIR__.'/config.php';if(empty($_SESSION['admin'])){http_response_code(404);exit('Not found');}
header('Content-Type: text/plain; charset=utf-8');
echo "Hongyuan server check\n";
echo "PHP_VERSION=".PHP_VERSION."\n";
echo "SAPI=".PHP_SAPI."\n";
echo "PDO=".(extension_loaded('pdo')?'OK':'MISSING')."\n";
echo "PDO_SQLITE=".(extension_loaded('pdo_sqlite')?'OK':'MISSING')."\n";
echo "SQLITE3=".(extension_loaded('sqlite3')?'OK':'MISSING')."\n";
echo "FILEINFO=".(extension_loaded('fileinfo')?'OK':'MISSING')."\n";
echo "MBSTRING=".(extension_loaded('mbstring')?'OK':'MISSING')."\n";
echo "UPLOADS=".(ini_get('file_uploads')?'ON':'OFF')."\n";
echo "UPLOAD_MAX_FILESIZE=".ini_get('upload_max_filesize')."\n";
echo "POST_MAX_SIZE=".ini_get('post_max_size')."\n";
echo "DATA_FILE=".__DIR__.'/data.sqlite'."\n";
echo "DATA_EXISTS=".(is_file(__DIR__.'/data.sqlite')?'YES':'NO')."\n";
echo "DATA_WRITABLE=".(is_writable(__DIR__.'/data.sqlite')?'YES':'NO')."\n";
echo "ROOT_WRITABLE=".(is_writable(__DIR__)?'YES':'NO')."\n";
foreach(['uploads','uploads/logo','uploads/media'] as $d){$p=__DIR__.'/'.$d;echo $d.'_EXISTS='.(is_dir($p)?'YES':'NO')."\n";echo $d.'_WRITABLE='.(is_dir($p)&&is_writable($p)?'YES':'NO')."\n";}
try{
 require_once __DIR__.'/inc/db.php';
 $pdo=db();
 echo "DB_CONNECT=OK\n";
 echo "DB_TABLES=".$pdo->query("SELECT COUNT(*) FROM sqlite_master WHERE type='table'")->fetchColumn()."\n";
}catch(Throwable $e){
 echo "DB_CONNECT=FAIL\n";
 echo "DB_ERROR=".str_replace(["\r","\n"],' ',get_class($e).': '.$e->getMessage())."\n";
}

