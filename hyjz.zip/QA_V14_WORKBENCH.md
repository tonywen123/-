# Hongyuan V14 Workbench QA

- Source: Hongyuan_FINAL_V13_5
- Workbench: true body-level floating window
- Drag: document-level Pointer Events, mouse/pen/touch
- Resize: 8 handles (N/S/E/W + 4 corners)
- Minimize: yes
- Maximize: yes
- Double-click title: maximize/restore
- Close / Esc: yes
- Position/size persistence: localStorage
- Undo / Redo: banner field + hidden editor state snapshots
- Ctrl/Cmd+Z, Ctrl/Cmd+Y, Ctrl/Cmd+S: yes
- Reset positions: yes
- Guides toggle: yes
- Preview: opens public homepage
- Save Slide from floating footer: yes
- Existing hidden form synchronization preserved
- Crop editor client limit aligned to server: 30 MB
- Slide duplication action added
- Admin navigation collapse persisted locally

## Static checks
- PHP index.php: PASS
- PHP save_slide.php: PASS
- All inline JavaScript blocks: PASS
- SQLite slides schema readable: PASS

## Important deployment test
After deployment, verify in browser:
1. Hero Carousel -> Edit Slide -> Open Editor.
2. Drag the dark title bar anywhere in the viewport.
3. Drag every edge/corner to resize.
4. Minimize, restore, maximize, restore.
5. Change a title field, Undo, Redo.
6. Save Slide from the floating footer.
7. Add a new slide and upload a banner.
8. Duplicate an existing slide.
