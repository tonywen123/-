HONGYUAN ORAFOL-STYLE ENTERPRISE WEBSITE - FINAL DEPLOY PACKAGE

IMPORTANT: This archive is already FLAT/ROOT-READY.
Upload/extract the CONTENTS of this archive directly into your website document root, e.g. /htdocs.
After extraction, /htdocs/index.php must exist.
Do NOT put these files inside another Hongyuan_FULL_ORAFOL folder.

Fresh installation:
1. Backup the existing site if needed.
2. Because this is a fresh package, remove the old website files from /htdocs if you do not need them.
3. Upload ALL files/folders from this archive directly into /htdocs.
4. Confirm /htdocs/index.php and /htdocs/data.sqlite exist.
5. Open your domain.
6. Admin: /admin/
7. Default admin password: admin123

Carousel button destinations:
- Explore Printable Vinyl -> category.php?slug=printable-vinyl
- Explore Lamination -> products.php

This package contains a fresh SQLite database and demo assets.

FINAL TYPOGRAPHY / EDITOR UPGRADE
- Settings now includes global font management for Body, Headings, Navigation, Buttons and Eyebrows.
- Supported Google Fonts include Inter, Roboto, Montserrat, Poppins, Open Sans, Lato, Oswald, Source Sans 3, Noto Sans, Noto Sans SC, Noto Sans JP, DM Sans, Manrope, Raleway, Work Sans and Nunito Sans.
- Optional custom Google Fonts CSS URL is supported and restricted to Google Fonts domains.
- Hero slides have per-element font family, weight, size, color, letter spacing and line-height controls.
- Long-form editable text areas now use a rich text editor with font, size, color, bold, italic, underline, alignment, letter spacing and line-height controls.
- Formatting is optional. No eyebrow, description, button or SEO field is required just to save/publish content. Structural requirements are limited to what the database/function genuinely needs.
