<?php
require_once __DIR__.'/inc/db.php';
$slug=trim($_GET['slug']??'');
$q=db()->prepare('SELECT * FROM articles WHERE slug=? AND published=1 LIMIT 1');$q->execute([$slug]);$a=$q->fetch(PDO::FETCH_ASSOC);
if(!$a){http_response_code(404);require __DIR__.'/404.php';exit;}
$page_title=$a['title'].' | '.setting('company_name');$page_desc=$a['excerpt']?:$a['title'];$canonical=site_url('article.php?slug='.urlencode($a['slug']));require __DIR__.'/inc/header.php';
?><section class="page-hero"><div class="wrap"><div class="breadcrumb"><a href="<?=e(site_url('index.php'))?>">Home</a> / News / <?=e($a['title'])?></div><div class="eyebrow">NEWS & TECHNICAL NOTES</div><h1><?=e($a['title'])?></h1><p><?=rich_text_clean($a['excerpt'])?></p></div></section><section class="section"><div class="wrap"><div class="detail"><div><?php if($a['image']):?><img class="application-hero-img" src="<?=e(site_url($a['image']))?>" alt="<?=e($a['title'])?>"><?php else:?><div style="background:#11161b;min-height:280px"></div><?php endif;?></div><div><span class="eyebrow dark"><?=e($a['created_at'])?></span><div class="rich-text"><?=rich_text_clean($a['content'])?></div></div></div></div></section><?php require __DIR__.'/inc/footer.php'; ?>
