<?php
// Hongyuan Technology — production configuration
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
ini_set('session.use_strict_mode','1');
ini_set('session.cookie_httponly','1');
ini_set('session.cookie_samesite','Lax');
if($secure) ini_set('session.cookie_secure','1');
session_start();
if (PHP_SAPI !== 'cli') {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
    if($secure) header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}
define('DB_PATH', __DIR__ . '/data.sqlite');
date_default_timezone_set('Asia/Shanghai');
function base_url(){ $d=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '')),'/'); return $d; }
function site_url($path=''){
    if($path==='') return base_url().'/';
    if(preg_match('~^(https?:\/\/|mailto:|tel:|#|javascript:)~i',$path)) return $path;
    $script=rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '')),'/');
    if(substr($script,-6)==='/admin') $script=rtrim(dirname($script),'/');
    return ($script==='/'?'':$script).'/'.ltrim($path,'/');
}
function current_scheme(){return (!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off')?'https':'http';}
function current_host(){return preg_replace('/[^A-Za-z0-9.:-]/','',$_SERVER['HTTP_HOST']??'');}
?>
