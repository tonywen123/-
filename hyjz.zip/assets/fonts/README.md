# Hongyuan bundled font library

Bundled local families: Inter, Roboto, Open Sans, Lato, Noto Sans, Noto Serif, Noto Sans Mono.

These font files were sourced from Debian-packaged distributions of the respective open fonts. Noto fonts are distributed under the SIL Open Font License (OFL) 1.1. Inter is distributed under OFL-1.1 / Apache-2.0. Lato is OFL-1.1.

Additional CJK families available in the CMS picker (Noto Sans/Serif SC, TC, JP, KR) are loaded from Google Fonts when selected; they are open-license Noto families.

The font files are bundled for use as part of the website, not sold as standalone font software.
