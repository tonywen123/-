import sqlite3, shutil, os, tempfile, json
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..')); src=os.path.join(ROOT,'data.sqlite')
fd,tmp=tempfile.mkstemp(suffix='.sqlite');os.close(fd);shutil.copy2(src,tmp)
passn=0

def ok(cond,msg):
 global passn
 if not cond: raise AssertionError(msg)
 passn+=1
c=sqlite3.connect(tmp);c.execute('PRAGMA foreign_keys=ON')
# 1 category create/edit/toggle/order/delete guard
c.execute("INSERT INTO categories(name,slug,parent_id,description,sort_order,enabled) VALUES(?,?,?,?,?,1)",('QA Family','qa-family',None,'test',99)); cid=c.execute('select last_insert_rowid()').fetchone()[0];ok(cid>0,'category create')
c.execute('update categories set description=? where id=?',('updated',cid));ok(c.execute('select description from categories where id=?',(cid,)).fetchone()[0]=='updated','category edit')
c.execute('update categories set enabled=0 where id=?',(cid,));ok(c.execute('select enabled from categories where id=?',(cid,)).fetchone()[0]==0,'category toggle')
c.execute('delete from categories where id=?',(cid,));ok(c.execute('select count(*) from categories where id=?',(cid,)).fetchone()[0]==0,'category delete')
# 2 product duplicate flow
p=c.execute('select * from products limit 1').fetchone();cols=[x[1] for x in c.execute('pragma table_info(products)')];d=dict(zip(cols,p));slug=d['slug']+'-qa';c.execute("insert into products(name,slug,category,description,overview,applications,specs,image,pdf,sort_order,featured,seo_title,seo_description,category_id,published,sku,image_alt,model,spec_rows,meta_keywords,video_url,sample_available,featured_label) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(d['name']+' QA',slug,d['category'],d['description'],d['overview'],d['applications'],d['specs'],d['image'],d['pdf'],d['sort_order']+1,d['featured'],d['seo_title'],d['seo_description'],d['category_id'],0,d['sku'],d['image_alt'],d['model'],d['spec_rows'],d['meta_keywords'],d['video_url'],d['sample_available'],d['featured_label']));pid=c.execute('select last_insert_rowid()').fetchone()[0];ok(pid>0,'product duplicate');c.execute('update products set published=1,meta_keywords=? where id=?',('qa,test',pid));ok(c.execute('select published from products where id=?',(pid,)).fetchone()[0]==1,'product publish');c.execute('delete from products where id=?',(pid,));ok(c.execute('select count(*) from products where id=?',(pid,)).fetchone()[0]==0,'product delete')
# 3 RFQ inquiry + items + sales pipeline
c.execute("insert into inquiries(name,company,email,status,source,purpose,country,lead_score) values(?,?,?,?,?,?,?,?)",('QA','QA Co','qa@example.com','New','rfq','Quote','US',80));iid=c.execute('select last_insert_rowid()').fetchone()[0];ok(iid>0,'inquiry create')
c.execute("insert into rfq_items(inquiry_id,product_id,product_name,sku,quantity) values(?,?,?,?,?)",(iid,p[0],p[1],d['sku'],'100 rolls'));ok(c.execute('select count(*) from rfq_items where inquiry_id=?',(iid,)).fetchone()[0]==1,'rfq item create')
c.execute("update inquiries set status='Contacted',priority='High',assigned_to='Tony',follow_up_date='2026-12-31',sales_note='QA note' where id=?",(iid,));r=c.execute('select status,priority,assigned_to,sales_note from inquiries where id=?',(iid,)).fetchone();ok(r==('Contacted','High','Tony','QA note'),'sales update')
# 4 slide create/update
c.execute("insert into slides(title,subtitle,text,button_text,button_url,image,sort_order,enabled,overlay_enabled,link_target,alt_text) values(?,?,?,?,?,?,?,?,?,?,?)",('QA Slide','QA','text','Products','products.php','assets/factory.jpg',99,0,0,'_self','QA'));sid=c.execute('select last_insert_rowid()').fetchone()[0];ok(sid>0,'slide create');c.execute("update slides set overlay_enabled=1,link_target='_blank' where id=?",(sid,));ok(c.execute('select overlay_enabled,link_target from slides where id=?',(sid,)).fetchone()==(1,'_blank'),'slide update')
# 5 search log
c.execute("insert into search_logs(query,results) values(?,?)",('printable vinyl',5));ok(c.execute('select count(*) from search_logs where query=?',('printable vinyl',)).fetchone()[0]>=1,'search log')
# 6 resource download counter
rid=c.execute('select id from resources limit 1').fetchone()[0];before=c.execute('select download_count from resources where id=?',(rid,)).fetchone()[0] or 0;c.execute('update resources set download_count=download_count+1 where id=?',(rid,));ok(c.execute('select download_count from resources where id=?',(rid,)).fetchone()[0]==before+1,'resource counter')
# 7 application product link
app=c.execute('select id from applications limit 1').fetchone()[0];c.execute('insert or ignore into application_products(application_id,product_id) values(?,?)',(app,p[0]));ok(c.execute('select count(*) from application_products where application_id=? and product_id=?',(app,p[0])).fetchone()[0]==1,'application product relation')
c.close();os.unlink(tmp);print('DB WORKFLOWS PASS',passn)
