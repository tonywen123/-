from pathlib import Path
import re, sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.')
checks={
 'global typography vars':'--font-body' in (root/'inc/header.php').read_text(),
 'google font loader':'typography_google_url' in (root/'inc/header.php').read_text(),
 'custom font URL guard':'fonts\\.(googleapis\\.com|gstatic\\.com)' in (root/'inc/header.php').read_text(),
 'rich editor':'rich-editor-toolbar' in (root/'admin/index.php').read_text(),
 'hero typography fields':'eyebrow_font' in (root/'admin/save_slide.php').read_text(),
 'overlay controls':'overlay_enabled' in (root/'admin/index.php').read_text(),
 'no eyebrow validation':'Title required' not in (root/'admin/save_application.php').read_text() and 'Title required' not in (root/'admin/save_resource.php').read_text(),
 'product category optional':'error=category' not in (root/'admin/save_product_pro.php').read_text(),
}
for k,v in checks.items(): print(('PASS' if v else 'FAIL')+' '+k)
print(f'PASS {sum(checks.values())} FAIL {len(checks)-sum(checks.values())}')
raise SystemExit(0 if all(checks.values()) else 1)
