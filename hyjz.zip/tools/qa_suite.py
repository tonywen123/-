#!/usr/bin/env python3
import os,re,sqlite3,subprocess,sys,json,zipfile
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
DB=os.path.join(ROOT,'data.sqlite')
PASS=[];FAIL=[];WARN=[]
def test(name,ok,detail=''):
    (PASS if ok else FAIL).append((name,detail))
def warn(name,detail=''): WARN.append((name,detail))
# 1-3 runtime/static
php_files=[]
for dp,_,fs in os.walk(ROOT):
    if '/uploads/' in dp.replace('\\','/') and dp.replace('\\','/').endswith('/uploads'): continue
    for f in fs:
        if f.endswith('.php'): php_files.append(os.path.join(dp,f))
for f in sorted(php_files):
    p=subprocess.run(['php','-l',f],capture_output=True,text=True)
    test('PHP syntax: '+os.path.relpath(f,ROOT),p.returncode==0,p.stderr.strip())
test('SQLite file exists',os.path.isfile(DB))
if os.path.isfile(DB):
    c=sqlite3.connect(DB)
    test('SQLite integrity',c.execute('PRAGMA integrity_check').fetchone()[0]=='ok')
    tables={r[0] for r in c.execute("select name from sqlite_master where type='table'")}
    required={'settings','categories','products','slides','gallery','inquiries','media','product_media','applications','application_products','resources','rfq_items','articles','search_logs'}
    test('Required tables present',required<=tables,str(sorted(required-tables)))
    def cols(t): return {r[1] for r in c.execute(f'pragma table_info({t})')}
    expected={
      'products':{'category_id','published','sku','image_alt','model','spec_rows','meta_keywords','video_url','sample_available','featured_label'},
      'inquiries':{'attachment','source','priority','assigned_to','follow_up_date','sales_note','last_contacted_at','utm_source','utm_medium','utm_campaign','landing_page','country','website','purpose','deadline','budget','language','lead_score','tags'},
      'slides':{'overlay_enabled','link_target','mobile_image','alt_text','image_fit','image_position'},
      'media':{'title','alt_text'},'resources':{'seo_title','seo_description','download_count'}
    }
    for t,cs in expected.items(): test(f'{t} migration columns',cs<=cols(t),str(sorted(cs-cols(t))))
    mains=c.execute('select id,name from categories where parent_id is null and enabled=1 order by sort_order,id').fetchall()
    test('Exactly ten visible main product families',len(mains)==10,str(mains))
    test('Products are not orphaned',c.execute('select count(*) from products p left join categories c on c.id=p.category_id where p.published=1 and c.id is null').fetchone()[0]==0)
    test('Unique product slugs',c.execute('select count(*) from products') .fetchone()[0]==c.execute('select count(distinct slug) from products').fetchone()[0])
    test('Unique category slugs',c.execute('select count(*) from categories').fetchone()[0]==c.execute('select count(distinct slug) from categories').fetchone()[0])
    for row in c.execute('select id,image from slides where enabled=1'):
        path=os.path.join(ROOT,row[1])
        test(f'Hero image exists #{row[0]}',os.path.isfile(path),row[1])
    for row in c.execute('select id,image from products where published=1 and image<>""'):
        test(f'Product image exists #{row[0]}',os.path.isfile(os.path.join(ROOT,row[1])),row[1])
    # 4-20 content sanity
    test('At least 20 products seeded',c.execute('select count(*) from products where published=1').fetchone()[0]>=20)
    test('At least 5 categories seeded',len(mains)>=5)
    test('Applications library seeded',c.execute('select count(*) from applications where published=1').fetchone()[0]>=4)
    test('Resources library seeded',c.execute('select count(*) from resources where published=1').fetchone()[0]>=3)
    test('No duplicate product names',c.execute('select count(*) from products') .fetchone()[0]==c.execute('select count(distinct name) from products').fetchone()[0])
    test('No duplicate category names',c.execute('select count(*) from categories').fetchone()[0]==c.execute('select count(distinct name) from categories').fetchone()[0])
    test('RFQ item table ready', 'inquiry_id' in cols('rfq_items'))
    c.close()
# Static feature tests
read=lambda f:open(os.path.join(ROOT,f),encoding='utf-8').read()
index=read('index.php');header=read('inc/header.php');footer=read('inc/footer.php');ht=read('.htaccess');robots=read('robots.txt');products=read('products.php');product=read('product.php');rfq=read('rfq.php');compare=read('compare.php');search=read('search.php');sitemap=read('sitemap.php');dbphp=read('inc/db.php')
checks=[
 ('Homepage has product finder CTA','products.php' in index),
 ('Homepage has solutions section','applications.php' in index),
 ('Homepage has resource section','resources.php' in index),
 ('Homepage has RFQ CTA','rfq.php' in index),
 ('Hero supports mobile image','mobile_image' in index),
 ('Hero overlay is opt-in','overlay_enabled' in index and '===1' in index),
 ('Hero supports swipe','touchstart' in index and 'touchend' in index),
 ('Hero respects reduced motion','prefers-reduced-motion' in index),
 ('Header has mega product navigation','mega-family' in header),
 ('Header has site search','search.php' in header),
 ('Header has RFQ CTA','rfq.php' in header),
 ('Header has Organization schema','Organization' in header),
 ('Header has WebSite SearchAction','SearchAction' in header),
 ('Footer has social links','footer-socials' in footer),
 ('Product finder has application filter','name="application"' in products),
 ('Product finder has finish filter','name="finish"' in products),
 ('Product finder has adhesive filter','name="adhesive"' in products),
 ('Product finder has printing filter','name="printing"' in products),
 ('Product finder has compare action','compare.php?add=' in products),
 ('Product detail has sample CTA','purpose=Sample' in product),
 ('Product detail has compare CTA','compare.php?add=' in product),
 ('Product detail has Product JSON-LD','@type' in product and 'Product' in product),
 ('RFQ supports multi-product','rfq_items' in rfq),
 ('RFQ supports attachment','attachment' in rfq),
 ('RFQ supports country','name="country"' in rfq),
 ('RFQ supports request purpose','name="purpose"' in rfq),
 ('RFQ supports UTM attribution','marketing_data' in rfq),
 ('Compare is session based','compare_ids' in compare),
 ('Search has autocomplete endpoint','search_suggest.php' in search),
 ('Search logs queries','log_search_query' in search),
 ('Sitemap includes resources','resources.php' in sitemap and 'resource.php?slug=' in sitemap),
 ('Sitemap includes articles','article.php?slug=' in sitemap),
 ('robots blocks admin','Disallow: /admin/' in robots),
 ('robots exposes sitemap','Sitemap:' in robots),
 ('Database is blocked by htaccess','data\\.sqlite' in ht),
 ('RFQ upload directory is private',os.path.isfile(os.path.join(ROOT,'uploads/rfq/.htaccess'))),
 ('Private attachment download route exists',os.path.isfile(os.path.join(ROOT,'admin/download_attachment.php'))),
 ('Admin upload media requires CSRF','verify_csrf' in read('admin/upload_media.php')),
 ('Admin gallery reorder requires CSRF','verify_csrf_get' in read('admin/save_gallery.php')),
 ('Admin delete requires CSRF','verify_csrf_get' in read('admin/delete.php')),
 ('Admin login regenerates session','session_regenerate_id' in read('inc/auth.php')),
 ('Admin login rate limited','login_rate_limited' in read('inc/auth.php')),
 ('Admin password hash supported','password_hash' in read('inc/auth.php')),
 ('Unique slugs enforced','unique_slug' in dbphp),
 ('Secure upload rejects SVG by default', "'image/svg+xml'" in dbphp and 'image/svg+xml' not in dbphp.split('function upload_file',1)[1].split('function category_tree',1)[0].split('detect_upload_mime',1)[0]),
 ('Search supports SKU/model','model LIKE' in search),
 ('Product meta keywords searchable','meta_keywords LIKE' in search),
 ('Resource download tracking','download_count=download_count+1' in read('download_resource.php')),
 ('Duplicate compare link removed','products.count("compare.php?add=")<=2'),
]
for name,ok in checks:
    if isinstance(ok,str): ok=eval(ok)
    test(name,bool(ok))
# Admin mutation audit: state-changing admin endpoints should have POST or CSRF GET protection
for f in ['save_product_pro.php','save_category.php','save_application.php','save_resource.php','save_article.php','save_settings.php','save_slide.php','upload.php','upload_media.php','update_inquiry.php','duplicate_product.php','delete.php','save_gallery.php']:
    s=read('admin/'+f)
    ok=('verify_csrf()' in s) or ('verify_csrf_get()' in s)
    test('Admin CSRF: '+f,ok)
# Link/route existence audit for explicit PHP targets
routes=['index.php','products.php','applications.php','resources.php','rfq.php','inquiry.php','contact.php','about.php','search.php','compare.php','sitemap.php','robots.txt','thankyou.php','product.php','category.php','application.php','resource.php','article.php','download_resource.php','search_suggest.php']
for r in routes:test('Route exists: '+r,os.path.isfile(os.path.join(ROOT,r)))
# Basic HTML/PHP anti-regression checks
for f in ['index.php','products.php','product.php','rfq.php','search.php','resources.php','resource.php','compare.php']:
    s=read(f);test('Escaping helper used: '+f,'<?=e(' in s or 'e(' in s)
print('\nHONGYUAN FINAL QA')
print('PASS',len(PASS),'FAIL',len(FAIL),'WARN',len(WARN))
for n,d in FAIL: print('FAIL:',n,d)
for n,d in WARN: print('WARN:',n,d)
print('PASS_RATE',round(len(PASS)/(len(PASS)+len(FAIL))*100,1) if PASS or FAIL else 0)
sys.exit(1 if FAIL else 0)
