# Hongyuan Final — QA Report

## Regression
- Static/runtime syntax assertions: **180 PASS / 0 FAIL**
- Database workflow assertions: **15 PASS / 0 FAIL**
- Full static QA regression loop: **40 consecutive runs passed** (30 before final security re-check + 10 after final password/schema re-check)
- Included SQLite database: integrity check passed.

## Major functional upgrades
1. ORAFOL-style enterprise information architecture.
2. Product Finder with family, subcategory, application and technical filters.
3. Product detail pages with structured specifications, TDS, related resources, related products, sample request, compare and RFQ actions.
4. Session-based four-product comparison.
5. Multi-product RFQ list with quantities.
6. Sample / quote / technical-support / OEM request purposes.
7. Country, company website, deadline, budget, language and UTM attribution fields.
8. Lead score, priority, assignment, follow-up date and sales notes in admin.
9. Search across products, applications, resources and news plus autocomplete.
10. Search analytics stored in SQLite.
11. Technical resource center with download counting.
12. SEO: canonical, robots, sitemap, Open Graph, Twitter metadata, Organization and WebSite structured data, Product JSON-LD.
13. Hero carousel: mobile image, alt text, optional overlay, target tab, crop/layout editor, swipe, pause, reduced-motion support.
14. Security: session regeneration, login rate limiting, password hashing, CSRF on admin mutations, secure upload MIME checks, protected SQLite file, private RFQ attachments.
15. Admin backup/export, content-health checks and search-demand visibility.

## Deliberate visual decision
The public hero overlay is **OFF by default**. This avoids the black-mask problem on pre-composed banner artwork. The CMS still supports an optional editable overlay when a future banner needs live text and CTA controls.

## Deployment
- Upload the package contents directly to the website root (e.g. `/htdocs/`).
- The included `data.sqlite` is already migrated for the new schema.
- Default admin: `admin / admin123`; change it immediately under Settings.
- Do not delete or rename `data.sqlite` or the `uploads/` directory.
- PHP 8.x + PDO SQLite is required.
