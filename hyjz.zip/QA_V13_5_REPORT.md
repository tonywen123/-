# Hongyuan V13.5 QA Report

## Fixed in V13.5
- Fixed Hero Carousel INSERT statement: the previous build had 53 columns but only 52 SQL placeholders, which caused new-slide saves/uploads to fail at the database layer.
- Rebuilt the floating Banner editor as a stable floating window mounted directly under `<body>` so layout/form ancestors cannot clip or interfere with it.
- Replaced mouse/touch drag handling with Pointer Events for one consistent drag path across mouse, pen and touch.
- Added reliable minimize, close, reopen, resize, Escape-to-close and viewport clamping.
- Replaced the old experimental opener node so duplicate click handlers cannot fight the stable implementation.
- Added an explicit `+ New Slide` action and slide count to Hero Carousel.
- Kept the unlimited-slide database/front-end model; there is no hard two-slide limit.

## Validation
- PHP syntax: `admin/index.php` PASS
- PHP syntax: `admin/save_slide.php` PASS
- Stable workbench JavaScript: Node syntax check PASS
- SQL INSERT columns/placeholders: 53 / 53 PASS
- SQLite statement preparation/execution against matching slide schema: PASS
- PNG MIME and dimensions validation: `image/png`, 1920x530 PASS
- No `LIMIT 2` in slide retrieval logic

## Production note
The final verification that depends on the hosting PHP SAPI (real multipart HTTP upload and the host's SQLite PDO driver) must be run on the production server. The code path has been fixed and the SQL/upload validation has been tested locally as far as this environment permits.
