HONGYUAN FULL WEBSITE - ORAFOL-INSPIRED B2B EDITION
Fresh complete installation. Includes database and uploads.
Admin: /admin/  Password: admin123 (change immediately).
Upload the contents of this folder into /htdocs.
This package intentionally includes a fresh data.sqlite and demo hero images.
